﻿Public Class Form1

	Const dblTaxRate As Double = 0.07
	Const dblRecreationalRate = 50.0			' full-day rate
	Const dblTouringRate = 60.0				' full-day rate
	Const dblPaddleRate = 5.0					' flat rate
	Const dblJacketRate = 3.0					' flat rate

	Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

		Dim blnAllOk As Boolean = True
		Dim dblAccessories As Double = 0.0
		Dim dblBasicRental As Double
		Dim dblSubtotal As Double
		Dim dblSalesTax As Double
		Dim dblFinalTotal As Double
		lblMessage.Text = String.Empty

		' Determine the full-day basic rental cost.
		If radRecreational.Checked Then
			dblBasicRental = dblRecreationalRate
		ElseIf radTouring.Checked Then
			dblBasicRental = dblTouringRate
		Else
			lblMessage.Text = "Please select a kayak type"
			blnAllOk = False
		End If

		' Reduce the price for half-day rentals.
		If radHalfDay.Checked Then
			dblBasicRental *= 0.5
		ElseIf radFullDay.Checked Then
			' do nothing
		Else
			lblMessage.Text = "Please select a rental duration"
			blnAllOk = False
		End If

		' Add the optional accessory costs.
		If chkPaddle.Checked Then
			dblAccessories += dblPaddleRate
		End If

		If chkLifeJacket.Checked Then
			dblAccessories += dblJacketRate
		End If

		'Continue if the input is complete.
		If blnAllOk Then
			' Do the calculations
			dblSubtotal = dblBasicRental + dblAccessories
			dblSalesTax = dblSubtotal * dblTaxRate
			dblFinalTotal = dblSubtotal + dblSalesTax

			' Display the results
			lblBasicRental.Text = dblBasicRental.ToString("n")
			lblAccessories.Text = dblAccessories.ToString("n")
			lblSubtotal.Text = dblSubtotal.ToString("n")
			lblSalesTax.Text = dblSalesTax.ToString("n")
			lblFinalTotal.Text = dblFinalTotal.ToString("n")
		End If

	End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

		radRecreational.Checked = False
		radTouring.Checked = False
		radHalfDay.Checked = False
		radFullDay.Checked = False
		chkPaddle.Checked = False
		chkLifeJacket.Checked = False

		lblBasicRental.Text = String.Empty
		lblAccessories.Text = String.Empty
		lblSubtotal.Text = String.Empty
		lblSalesTax.Text = String.Empty
		lblFinalTotal.Text = String.Empty
		lblMessage.Text = String.Empty
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.lblMessage = New System.Windows.Forms.Label()
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.btnCalculate = New System.Windows.Forms.Button()
		Me.btnClose = New System.Windows.Forms.Button()
		Me.btnClear = New System.Windows.Forms.Button()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.lblFinalTotal = New System.Windows.Forms.Label()
		Me.lblSalesTax = New System.Windows.Forms.Label()
		Me.lblSubtotal = New System.Windows.Forms.Label()
		Me.lblAccessories = New System.Windows.Forms.Label()
		Me.lblBasicRental = New System.Windows.Forms.Label()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.cboKayakType = New System.Windows.Forms.ComboBox()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.radFullDay = New System.Windows.Forms.RadioButton()
		Me.radHalfDay = New System.Windows.Forms.RadioButton()
		Me.GroupBox3 = New System.Windows.Forms.GroupBox()
		Me.lstAccessories = New System.Windows.Forms.CheckedListBox()
		Me.MyToolTips = New System.Windows.Forms.ToolTip(Me.components)
		Me.Panel1.SuspendLayout()
		Me.Panel2.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.GroupBox3.SuspendLayout()
		Me.SuspendLayout()
		'
		'Panel1
		'
		Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.Panel1.Controls.Add(Me.Label1)
		Me.Panel1.Location = New System.Drawing.Point(21, 12)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(477, 45)
		Me.Panel1.TabIndex = 0
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.Blue
		Me.Label1.Location = New System.Drawing.Point(149, 8)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(165, 29)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Kayak Rental"
		'
		'lblMessage
		'
		Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblMessage.ForeColor = System.Drawing.Color.Red
		Me.lblMessage.Location = New System.Drawing.Point(21, 217)
		Me.lblMessage.Name = "lblMessage"
		Me.lblMessage.Size = New System.Drawing.Size(477, 25)
		Me.lblMessage.TabIndex = 8
		'
		'Panel2
		'
		Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLight
		Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Panel2.Controls.Add(Me.btnCalculate)
		Me.Panel2.Controls.Add(Me.btnClose)
		Me.Panel2.Controls.Add(Me.btnClear)
		Me.Panel2.Controls.Add(Me.Label12)
		Me.Panel2.Controls.Add(Me.Label13)
		Me.Panel2.Controls.Add(Me.Label14)
		Me.Panel2.Controls.Add(Me.Label11)
		Me.Panel2.Controls.Add(Me.Label10)
		Me.Panel2.Controls.Add(Me.lblFinalTotal)
		Me.Panel2.Controls.Add(Me.lblSalesTax)
		Me.Panel2.Controls.Add(Me.lblSubtotal)
		Me.Panel2.Controls.Add(Me.lblAccessories)
		Me.Panel2.Controls.Add(Me.lblBasicRental)
		Me.Panel2.Location = New System.Drawing.Point(21, 259)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(477, 240)
		Me.Panel2.TabIndex = 9
		'
		'btnCalculate
		'
		Me.btnCalculate.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnCalculate.Location = New System.Drawing.Point(316, 66)
		Me.btnCalculate.Name = "btnCalculate"
		Me.btnCalculate.Size = New System.Drawing.Size(94, 36)
		Me.btnCalculate.TabIndex = 45
		Me.btnCalculate.Text = "Calculate"
		Me.MyToolTips.SetToolTip(Me.btnCalculate, "Calculates the total cost of the rental, including" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the basic rental, accessories" & _
		  ", and sales tax.")
		Me.btnCalculate.UseVisualStyleBackColor = False
		'
		'btnClose
		'
		Me.btnClose.Location = New System.Drawing.Point(316, 172)
		Me.btnClose.Name = "btnClose"
		Me.btnClose.Size = New System.Drawing.Size(94, 34)
		Me.btnClose.TabIndex = 44
		Me.btnClose.Text = "Close"
		Me.btnClose.UseVisualStyleBackColor = True
		'
		'btnClear
		'
		Me.btnClear.Location = New System.Drawing.Point(316, 119)
		Me.btnClear.Name = "btnClear"
		Me.btnClear.Size = New System.Drawing.Size(94, 34)
		Me.btnClear.TabIndex = 43
		Me.btnClear.Text = "Clear"
		Me.btnClear.UseVisualStyleBackColor = True
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.Location = New System.Drawing.Point(55, 185)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(129, 18)
		Me.Label12.TabIndex = 42
		Me.Label12.Text = "Final Amount Due:"
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label13
		'
		Me.Label13.AutoSize = True
		Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.Location = New System.Drawing.Point(108, 146)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(77, 18)
		Me.Label13.TabIndex = 41
		Me.Label13.Text = "Sales Tax:"
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label14
		'
		Me.Label14.AutoSize = True
		Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.Location = New System.Drawing.Point(118, 106)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(66, 18)
		Me.Label14.TabIndex = 40
		Me.Label14.Text = "Subtotal:"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label11
		'
		Me.Label11.AutoSize = True
		Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.Location = New System.Drawing.Point(90, 66)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(94, 18)
		Me.Label11.TabIndex = 39
		Me.Label11.Text = "Accessories:"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label10.Location = New System.Drawing.Point(90, 22)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(95, 18)
		Me.Label10.TabIndex = 38
		Me.Label10.Text = "Basic Rental:"
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblFinalTotal
		'
		Me.lblFinalTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblFinalTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblFinalTotal.Location = New System.Drawing.Point(191, 181)
		Me.lblFinalTotal.Name = "lblFinalTotal"
		Me.lblFinalTotal.Size = New System.Drawing.Size(63, 27)
		Me.lblFinalTotal.TabIndex = 37
		Me.lblFinalTotal.Text = "0.00"
		Me.lblFinalTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblSalesTax
		'
		Me.lblSalesTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblSalesTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblSalesTax.Location = New System.Drawing.Point(191, 141)
		Me.lblSalesTax.Name = "lblSalesTax"
		Me.lblSalesTax.Size = New System.Drawing.Size(63, 27)
		Me.lblSalesTax.TabIndex = 36
		Me.lblSalesTax.Text = "0.00"
		Me.lblSalesTax.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblSubtotal
		'
		Me.lblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblSubtotal.Location = New System.Drawing.Point(191, 101)
		Me.lblSubtotal.Name = "lblSubtotal"
		Me.lblSubtotal.Size = New System.Drawing.Size(63, 27)
		Me.lblSubtotal.TabIndex = 35
		Me.lblSubtotal.Text = "0.00"
		Me.lblSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblAccessories
		'
		Me.lblAccessories.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblAccessories.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblAccessories.Location = New System.Drawing.Point(191, 60)
		Me.lblAccessories.Name = "lblAccessories"
		Me.lblAccessories.Size = New System.Drawing.Size(63, 27)
		Me.lblAccessories.TabIndex = 34
		Me.lblAccessories.Text = "0.00"
		Me.lblAccessories.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblBasicRental
		'
		Me.lblBasicRental.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblBasicRental.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblBasicRental.Location = New System.Drawing.Point(191, 18)
		Me.lblBasicRental.Name = "lblBasicRental"
		Me.lblBasicRental.Size = New System.Drawing.Size(63, 27)
		Me.lblBasicRental.TabIndex = 33
		Me.lblBasicRental.Text = "0.00"
		Me.lblBasicRental.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'GroupBox1
		'
		Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
		Me.GroupBox1.Controls.Add(Me.cboKayakType)
		Me.GroupBox1.Location = New System.Drawing.Point(21, 72)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(217, 66)
		Me.GroupBox1.TabIndex = 10
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Kayak type"
		'
		'cboKayakType
		'
		Me.cboKayakType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboKayakType.FormattingEnabled = True
		Me.cboKayakType.Items.AddRange(New Object() {"Solo Recreational", "Solo Touring", "Tandem Recreational", "Tandem Touring"})
		Me.cboKayakType.Location = New System.Drawing.Point(18, 29)
		Me.cboKayakType.Name = "cboKayakType"
		Me.cboKayakType.Size = New System.Drawing.Size(182, 24)
		Me.cboKayakType.TabIndex = 0
		Me.MyToolTips.SetToolTip(Me.cboKayakType, "Select the type of kayak you would like to use. Tandem kayaks are $20 more.")
		'
		'GroupBox2
		'
		Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLight
		Me.GroupBox2.Controls.Add(Me.radFullDay)
		Me.GroupBox2.Controls.Add(Me.radHalfDay)
		Me.GroupBox2.Location = New System.Drawing.Point(21, 144)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(217, 64)
		Me.GroupBox2.TabIndex = 11
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "Rental duration"
		'
		'radFullDay
		'
		Me.radFullDay.AutoSize = True
		Me.radFullDay.Location = New System.Drawing.Point(114, 25)
		Me.radFullDay.Name = "radFullDay"
		Me.radFullDay.Size = New System.Drawing.Size(75, 21)
		Me.radFullDay.TabIndex = 1
		Me.radFullDay.TabStop = True
		Me.radFullDay.Text = "Full day"
		Me.MyToolTips.SetToolTip(Me.radFullDay, "A full day rental is from 1:00 pm to 5:00 pm")
		Me.radFullDay.UseVisualStyleBackColor = True
		'
		'radHalfDay
		'
		Me.radHalfDay.AutoSize = True
		Me.radHalfDay.Location = New System.Drawing.Point(18, 25)
		Me.radHalfDay.Name = "radHalfDay"
		Me.radHalfDay.Size = New System.Drawing.Size(78, 21)
		Me.radHalfDay.TabIndex = 0
		Me.radHalfDay.TabStop = True
		Me.radHalfDay.Text = "Half day"
		Me.MyToolTips.SetToolTip(Me.radHalfDay, "A half day rental is from 9:00 am to 1:00 pm")
		Me.radHalfDay.UseVisualStyleBackColor = True
		'
		'GroupBox3
		'
		Me.GroupBox3.BackColor = System.Drawing.SystemColors.ControlLight
		Me.GroupBox3.Controls.Add(Me.lstAccessories)
		Me.GroupBox3.Location = New System.Drawing.Point(254, 72)
		Me.GroupBox3.Name = "GroupBox3"
		Me.GroupBox3.Size = New System.Drawing.Size(244, 136)
		Me.GroupBox3.TabIndex = 13
		Me.GroupBox3.TabStop = False
		Me.GroupBox3.Text = "Accessories"
		'
		'lstAccessories
		'
		Me.lstAccessories.CheckOnClick = True
		Me.lstAccessories.FormattingEnabled = True
		Me.lstAccessories.Items.AddRange(New Object() {"Box Lunch", "Fishing gear", "High-tech paddle", "Inflatable life vest", "Snorkeling gear"})
		Me.lstAccessories.Location = New System.Drawing.Point(17, 29)
		Me.lstAccessories.Name = "lstAccessories"
		Me.lstAccessories.Size = New System.Drawing.Size(206, 94)
		Me.lstAccessories.TabIndex = 0
		Me.MyToolTips.SetToolTip(Me.lstAccessories, "Each accessory is $10. You may select any combination of these.")
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(519, 513)
		Me.Controls.Add(Me.GroupBox3)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.GroupBox1)
		Me.Controls.Add(Me.Panel2)
		Me.Controls.Add(Me.lblMessage)
		Me.Controls.Add(Me.Panel1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "Form1"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Tony's Best Kayak Outfitters"
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.Panel2.ResumeLayout(False)
		Me.Panel2.PerformLayout()
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.GroupBox3.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblMessage As System.Windows.Forms.Label
	Friend WithEvents Panel2 As System.Windows.Forms.Panel
	Friend WithEvents lblFinalTotal As System.Windows.Forms.Label
	Friend WithEvents lblSalesTax As System.Windows.Forms.Label
	Friend WithEvents lblSubtotal As System.Windows.Forms.Label
	Friend WithEvents lblAccessories As System.Windows.Forms.Label
	Friend WithEvents lblBasicRental As System.Windows.Forms.Label
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents Label13 As System.Windows.Forms.Label
	Friend WithEvents Label14 As System.Windows.Forms.Label
	Friend WithEvents btnCalculate As System.Windows.Forms.Button
	Friend WithEvents btnClose As System.Windows.Forms.Button
	Friend WithEvents btnClear As System.Windows.Forms.Button
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Friend WithEvents radFullDay As System.Windows.Forms.RadioButton
	Friend WithEvents radHalfDay As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cboKayakType As System.Windows.Forms.ComboBox
    Friend WithEvents lstAccessories As System.Windows.Forms.CheckedListBox
    Friend WithEvents MyToolTips As System.Windows.Forms.ToolTip
End Class

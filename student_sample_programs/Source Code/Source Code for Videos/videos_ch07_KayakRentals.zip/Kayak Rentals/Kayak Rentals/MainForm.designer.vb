﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.MyToolTips = New System.Windows.Forms.ToolTip(Me.components)
		Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuCustomer = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuCustomerRentals = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuManager = New System.Windows.Forms.ToolStripMenuItem()
		Me.PictureBox1 = New System.Windows.Forms.PictureBox()
		Me.btnKayakRentals = New System.Windows.Forms.Button()
		Me.Panel1.SuspendLayout()
		Me.MenuStrip1.SuspendLayout()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
				Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.Panel1.Controls.Add(Me.Label1)
		Me.Panel1.Location = New System.Drawing.Point(3, 26)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(512, 44)
		Me.Panel1.TabIndex = 0
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.Blue
		Me.Label1.Location = New System.Drawing.Point(149, 8)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(165, 29)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Kayak Rental"
		'
		'MenuStrip1
		'
		Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuCustomer, Me.mnuManager})
		Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.MenuStrip1.Name = "MenuStrip1"
		Me.MenuStrip1.Size = New System.Drawing.Size(519, 24)
		Me.MenuStrip1.TabIndex = 1
		Me.MenuStrip1.Text = "MenuStrip1"
		'
		'mnuFile
		'
		Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileExit})
		Me.mnuFile.Name = "mnuFile"
		Me.mnuFile.Size = New System.Drawing.Size(37, 20)
		Me.mnuFile.Text = "&File"
		'
		'mnuFileExit
		'
		Me.mnuFileExit.Name = "mnuFileExit"
		Me.mnuFileExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
		Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
		Me.mnuFileExit.Text = "E&xit"
		'
		'mnuCustomer
		'
		Me.mnuCustomer.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCustomerRentals})
		Me.mnuCustomer.Name = "mnuCustomer"
		Me.mnuCustomer.Size = New System.Drawing.Size(71, 20)
		Me.mnuCustomer.Text = "&Customer"
		'
		'mnuCustomerRentals
		'
		Me.mnuCustomerRentals.Name = "mnuCustomerRentals"
		Me.mnuCustomerRentals.Size = New System.Drawing.Size(152, 22)
		Me.mnuCustomerRentals.Text = "&Rentals"
		'
		'mnuManager
		'
		Me.mnuManager.Name = "mnuManager"
		Me.mnuManager.Size = New System.Drawing.Size(66, 20)
		Me.mnuManager.Text = "&Manager"
		'
		'PictureBox1
		'
		Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
		Me.PictureBox1.Location = New System.Drawing.Point(124, 89)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(278, 149)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.PictureBox1.TabIndex = 2
		Me.PictureBox1.TabStop = False
		'
		'btnKayakRentals
		'
		Me.btnKayakRentals.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnKayakRentals.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnKayakRentals.Location = New System.Drawing.Point(157, 252)
		Me.btnKayakRentals.Name = "btnKayakRentals"
		Me.btnKayakRentals.Size = New System.Drawing.Size(197, 40)
		Me.btnKayakRentals.TabIndex = 3
		Me.btnKayakRentals.Text = "Rent a Kayak"
		Me.btnKayakRentals.UseVisualStyleBackColor = False
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
		Me.ClientSize = New System.Drawing.Size(519, 304)
		Me.Controls.Add(Me.btnKayakRentals)
		Me.Controls.Add(Me.PictureBox1)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.MenuStrip1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.MainMenuStrip = Me.MenuStrip1
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "MainForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Tony's Best Kayak Outfitters"
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.MenuStrip1.ResumeLayout(False)
		Me.MenuStrip1.PerformLayout()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents MyToolTips As System.Windows.Forms.ToolTip
	Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
	Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents mnuCustomer As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents mnuManager As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents mnuCustomerRentals As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
	Friend WithEvents btnKayakRentals As System.Windows.Forms.Button
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ManagerLoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.txtPassword = New System.Windows.Forms.TextBox()
		Me.txtUserName = New System.Windows.Forms.TextBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.lblMessage = New System.Windows.Forms.Label()
		Me.btnLogin = New System.Windows.Forms.Button()
		Me.btnCancel = New System.Windows.Forms.Button()
		Me.lnkForgotPassword = New System.Windows.Forms.LinkLabel()
		Me.Panel1.SuspendLayout()
		Me.Panel2.SuspendLayout()
		Me.SuspendLayout()
		'
		'Panel1
		'
		Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.Panel1.Controls.Add(Me.Label1)
		Me.Panel1.Location = New System.Drawing.Point(12, 12)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(401, 45)
		Me.Panel1.TabIndex = 2
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.Blue
		Me.Label1.Location = New System.Drawing.Point(93, 7)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(187, 29)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Manager Login"
		'
		'Panel2
		'
		Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Panel2.Controls.Add(Me.lnkForgotPassword)
		Me.Panel2.Controls.Add(Me.btnCancel)
		Me.Panel2.Controls.Add(Me.btnLogin)
		Me.Panel2.Controls.Add(Me.lblMessage)
		Me.Panel2.Controls.Add(Me.Label2)
		Me.Panel2.Controls.Add(Me.Label4)
		Me.Panel2.Controls.Add(Me.txtPassword)
		Me.Panel2.Controls.Add(Me.txtUserName)
		Me.Panel2.Controls.Add(Me.Label3)
		Me.Panel2.Location = New System.Drawing.Point(13, 74)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(401, 220)
		Me.Panel2.TabIndex = 17
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(16, 16)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(346, 17)
		Me.Label3.TabIndex = 12
		Me.Label3.Text = "Managers must log in with a username and password:"
		'
		'txtPassword
		'
		Me.txtPassword.Location = New System.Drawing.Point(113, 93)
		Me.txtPassword.Name = "txtPassword"
		Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
		Me.txtPassword.Size = New System.Drawing.Size(133, 23)
		Me.txtPassword.TabIndex = 16
		'
		'txtUserName
		'
		Me.txtUserName.Location = New System.Drawing.Point(112, 55)
		Me.txtUserName.Name = "txtUserName"
		Me.txtUserName.Size = New System.Drawing.Size(133, 23)
		Me.txtUserName.TabIndex = 15
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(27, 55)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(77, 17)
		Me.Label2.TabIndex = 17
		Me.Label2.Text = "Username:"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(27, 93)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(73, 17)
		Me.Label4.TabIndex = 18
		Me.Label4.Text = "Password:"
		'
		'lblMessage
		'
		Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblMessage.ForeColor = System.Drawing.Color.Black
		Me.lblMessage.Location = New System.Drawing.Point(19, 176)
		Me.lblMessage.Name = "lblMessage"
		Me.lblMessage.Size = New System.Drawing.Size(343, 25)
		Me.lblMessage.TabIndex = 19
		'
		'btnLogin
		'
		Me.btnLogin.Location = New System.Drawing.Point(271, 50)
		Me.btnLogin.Name = "btnLogin"
		Me.btnLogin.Size = New System.Drawing.Size(91, 32)
		Me.btnLogin.TabIndex = 20
		Me.btnLogin.Text = "Log In"
		Me.btnLogin.UseVisualStyleBackColor = True
		'
		'btnCancel
		'
		Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnCancel.Location = New System.Drawing.Point(271, 93)
		Me.btnCancel.Name = "btnCancel"
		Me.btnCancel.Size = New System.Drawing.Size(91, 32)
		Me.btnCancel.TabIndex = 21
		Me.btnCancel.Text = "Cancel"
		Me.btnCancel.UseVisualStyleBackColor = True
		'
		'lnkForgotPassword
		'
		Me.lnkForgotPassword.AutoSize = True
		Me.lnkForgotPassword.Location = New System.Drawing.Point(16, 140)
		Me.lnkForgotPassword.Name = "lnkForgotPassword"
		Me.lnkForgotPassword.Size = New System.Drawing.Size(138, 17)
		Me.lnkForgotPassword.TabIndex = 22
		Me.lnkForgotPassword.TabStop = True
		Me.lnkForgotPassword.Text = "I forgot my password"
		'
		'ManagerLoginForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(428, 308)
		Me.Controls.Add(Me.Panel2)
		Me.Controls.Add(Me.Panel1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
		Me.MaximizeBox = False
		Me.Name = "ManagerLoginForm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Manager Login"
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.Panel2.ResumeLayout(False)
		Me.Panel2.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Panel2 As System.Windows.Forms.Panel
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents txtPassword As System.Windows.Forms.TextBox
	Friend WithEvents txtUserName As System.Windows.Forms.TextBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents lblMessage As System.Windows.Forms.Label
	Friend WithEvents btnLogin As System.Windows.Forms.Button
	Friend WithEvents btnCancel As System.Windows.Forms.Button
	Friend WithEvents lnkForgotPassword As System.Windows.Forms.LinkLabel
End Class

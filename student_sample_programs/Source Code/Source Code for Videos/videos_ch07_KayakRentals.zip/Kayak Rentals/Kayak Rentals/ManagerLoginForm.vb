﻿Public Class ManagerLoginForm

	ReadOnly Manager_Name As String = "smith"
	ReadOnly Manager_Pwd As String = "password"

	Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

		If txtPassword.Text = Manager_Pwd Then
			Me.DialogResult = Windows.Forms.DialogResult.OK
			Me.Close()
		Else
			lblMessage.Text = "Username/password combination not recognized."
		End If
	End Sub

	Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
		Me.DialogResult = Windows.Forms.DialogResult.Cancel
		Me.Close()
	End Sub

	Private Sub lnkForgotPassword_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkForgotPassword.LinkClicked

		If txtUserName.Text = Manager_Name Then
			lblMessage.Text = "Your password will be emailed to you."
		Else
			lblMessage.Text = "Sorry, your username is not on file."
		End If
	End Sub
End Class
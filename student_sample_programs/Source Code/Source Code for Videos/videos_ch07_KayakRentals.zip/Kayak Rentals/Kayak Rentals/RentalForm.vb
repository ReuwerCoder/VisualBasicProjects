﻿Public Class RentalForm

	Const dblTaxRate As Double = 0.07		 ' sales tax rate
	Const dblBasicRentalRate As Double = 50.0	  ' daily rate
	Const dblTandemSurcharge As Double = 20.0
	Const dblAccessoryPrice As Double = 5.0

	Private dblAccessories As Double = 0.0
	Private dblBasicRental As Double
	Private dblSubtotal As Double
	Private dblSalesTax As Double
	Private dblFinalTotal As Double

	Private Sub CalcBasicRental()

		Dim strKayak As String = cboKayakType.SelectedItem.ToString()
		dblBasicRental = dblBasicRentalRate

		If strKayak.Contains("Tandem") Then
			dblBasicRental += dblTandemSurcharge
		End If

		' Reduce the daily rental rate for half-day rentals.
		If radHalfDay.Checked Then
			dblBasicRental *= 0.5
		End If
	End Sub

	Private Sub CalcAccessoryCosts()

		' Count the number of accessories. 
		Dim intCount As Integer = 0
		For i As Integer = 0 To lstAccessories.Items.Count - 1
			If lstAccessories.GetItemChecked(i) Then
				intCount += 1
			End If
		Next

		' Multiply the number of accessories by a standard price.
		dblAccessories = intCount * dblAccessoryPrice
	End Sub

	Private Sub CalcuSummaryTotals()

		dblSubtotal = dblBasicRental + dblAccessories
		dblSalesTax = dblSubtotal * dblTaxRate
		dblFinalTotal = dblSubtotal + dblSalesTax
	End Sub

	Private Function ValidateKayakType() As Boolean

		If cboKayakType.SelectedItem Is Nothing Then
			lblMessage.Text = "Please select a kayak type"
			Return False
		Else
			Return True
		End If
	End Function

	Private Function ValidateRentalDuration() As Boolean

		If Not (radFullDay.Checked Or radHalfDay.Checked) Then
			lblMessage.Text = "Please select a rental duration"
			Return False
		Else
			Return True
		End If
	End Function

	Private Sub btnCalculate_Click() Handles btnCalculate.Click

		lblMessage.Text = String.Empty

		' Make sure a kayak type has been selected.
		' Make sure the rental duration has been selected.
		'Continue if the input is complete.
		If ValidateKayakType() AndAlso ValidateRentalDuration() Then

			' Do all of the calculations.
			CalcBasicRental()
			CalcAccessoryCosts()
			CalcuSummaryTotals()

			' Display the results
			lblBasicRental.Text = dblBasicRental.ToString("n")
			lblAccessories.Text = dblAccessories.ToString("n")
			lblSubtotal.Text = dblSubtotal.ToString("n")
			lblSalesTax.Text = dblSalesTax.ToString("n")
			lblFinalTotal.Text = dblFinalTotal.ToString("n")
		End If

	End Sub

	Private Sub btnClear_Click() Handles btnClear.Click

		cboKayakType.SelectedIndex = -1
		lstAccessories.SelectedItems.Clear()
		radHalfDay.Checked = False
		radFullDay.Checked = False

		' Uncheck all accessories.
		For i As Integer = 0 To lstAccessories.Items.Count - 1
			lstAccessories.SetItemChecked(i, False)
		Next

		lblBasicRental.Text = String.Empty
		lblAccessories.Text = String.Empty
		lblSubtotal.Text = String.Empty
		lblSalesTax.Text = String.Empty
		lblFinalTotal.Text = String.Empty
		lblMessage.Text = String.Empty
	End Sub

	Private Sub btnClose_Click() Handles btnClose.Click
		Me.Close()
	End Sub

End Class
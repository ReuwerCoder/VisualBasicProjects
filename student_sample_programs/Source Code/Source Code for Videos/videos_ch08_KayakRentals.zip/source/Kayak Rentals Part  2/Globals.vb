﻿Imports System.Collections.Generic               '**

Module Globals

    Public rentalHistory As New List(Of Rental)

End Module

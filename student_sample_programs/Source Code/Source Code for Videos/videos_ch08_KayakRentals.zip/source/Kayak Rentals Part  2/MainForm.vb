﻿Public Class MainForm

    Private Sub ShowCustomerRentals()
        Dim frm As New RentalForm
        frm.ShowDialog()
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuCustomerRentals_Click(sender As Object, e As EventArgs) Handles mnuCustomerRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuManager_Click(sender As Object, e As EventArgs) Handles mnuManager.Click
        Dim frm As New ManagerMainForm
        frm.ShowDialog()
    End Sub

    Private Sub btnKayakRentals_Click(sender As Object, e As EventArgs) Handles btnKayakRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuCustomerTour_Click(sender As Object, e As EventArgs) Handles mnuCustomerTour.Click
        Dim frm As New SelectTourForm
        frm.ShowDialog()
    End Sub

End Class
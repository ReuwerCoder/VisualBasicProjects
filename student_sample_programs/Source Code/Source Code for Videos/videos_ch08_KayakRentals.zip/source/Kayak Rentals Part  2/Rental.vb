﻿Public Class Rental

    Property KayakType As String
    Property Duration As String
    Property Accessories As String
    Property BasicRental As String
    Property AccessoryCost As String
    Property SalesTax As String
    Property FinalTotal As String

    Public Overrides Function ToString() As String
        Return "Type: " & KayakType & "\n" &
        "Duration: " & Duration & vbCrLf &
        "Accessories: " & Accessories & vbCrLf &
        "Accessory cost: " & AccessoryCost & vbCrLf &
        "Sales tax: " & SalesTax & vbCrLf &
        "Final amount: " & FinalTotal
    End Function

End Class

﻿Public Class SelectTourForm

    ReadOnly dblTourPrices() As Double = {55.0, 85.0, 105.0, 130.0}
    ReadOnly strTourNames() As String = {"Half-day harbor tour",
        "Full-day Rattlesnake Key",
        "Overnight Florida Bay",
        "Two-night Blackwater Sound"}

    Private Sub SelectTourForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each tour As String In strTourNames
            lstTours.Items.Add(tour)
        Next
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Dim index As Integer = lstTours.SelectedIndex
        If index = -1 Then
            lblStatus.Text = "Please select a tour from the list"
            Return
        Else
            lblPrice.Text = dblTourPrices(index).ToString("c")
            lblStatus.Text = "Thank you for selecting a tour."
        End If

    End Sub

    Private Sub lstTours_SelectedIndexChanged() Handles lstTours.SelectedIndexChanged

        Dim index As Integer = lstTours.SelectedIndex
        lblPrice.Text = dblTourPrices(index).ToString("c")
        lblStatus.Text = String.Empty
    End Sub
End Class
﻿Module Globals

    Public rentalHistory As New List(Of Rental)

    ' These Lines added for Part 3
    Public KayakTypes As String() = {
        "Solo Recreational", "Solo Touring",
        "Solo Ocean", "Tandem Recreational",
        "Tandem Touring", "Tandem Ocean"}

    Public HalfDayKayakRates As Double() = {40.0, 48.0, 42.0, 48.0, 52.0, 55.0}
    Public FullDayKayakRates As Double() = {70.0, 74.0, 78.0, 75.0, 80.0, 85.0}

End Module

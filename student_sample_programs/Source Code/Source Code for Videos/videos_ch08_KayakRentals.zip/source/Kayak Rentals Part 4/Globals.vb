﻿Module Globals

    'Add ReadOnly keyword to all constants!

    Public g_RentalHistory As New List(Of Rental)   'RENAME THIS
    Public g_TourHistory As New List(Of Tour)

    Public ReadOnly KayakTypes As String() = {
        "Solo Recreational", "Solo Touring",
        "Solo Ocean", "Tandem Recreational",
        "Tandem Touring", "Tandem Ocean"}

    Public ReadOnly HalfDayKayakRates As Double() = {40.0, 48.0, 42.0, 48.0, 52.0, 55.0}
    Public ReadOnly FullDayKayakRates As Double() = {70.0, 74.0, 78.0, 75.0, 80.0, 85.0}

End Module

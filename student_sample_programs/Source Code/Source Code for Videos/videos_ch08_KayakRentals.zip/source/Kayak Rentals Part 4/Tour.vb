﻿Public Class Tour

    Property TourName As String
    Property Price As Double
    Property CustomerFirstName As String
    Property CustomerLastName As String

    Public Overrides Function ToString() As String

        Return CustomerFirstName & " " & CustomerLastName &
          " signed up for " & TourName &
          ", cost = " & Price.ToString("c")
    End Function

End Class

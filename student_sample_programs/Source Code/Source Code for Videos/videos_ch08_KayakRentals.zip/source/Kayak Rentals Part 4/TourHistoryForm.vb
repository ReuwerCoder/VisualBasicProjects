﻿Public Class TourHistoryForm

    Private Sub TourHistoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each T As Tour In g_TourHistory
            lstHistory.Items.Add(T.ToString())
        Next

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
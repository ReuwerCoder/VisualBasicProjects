﻿Public Class ManagerMainForm

	Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
		Me.Close()
	End Sub

	Private Sub ManagerMainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Dim frm As New ManagerLoginForm

		' If the user clicked the Cancel button, close the Manager form.
		Dim result As DialogResult = frm.ShowDialog()
		If result = Windows.Forms.DialogResult.Cancel Then
			Me.Close()
		End If
	End Sub

    Private Sub btnRentalHistory_Click(sender As Object, e As EventArgs) Handles btnRentalHistory.Click
        Dim frm As New RentalHistoryForm
        frm.ShowDialog()
    End Sub

    Private Sub btnTourHistory_Click(sender As Object, e As EventArgs) Handles btnTourHistory.Click
        Dim frm As New TourHistoryForm
        frm.ShowDialog()
    End Sub
End Class
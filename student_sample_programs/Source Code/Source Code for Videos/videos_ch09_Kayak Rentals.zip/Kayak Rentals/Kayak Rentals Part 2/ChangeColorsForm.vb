﻿Public Class ChangeColorsForm

    Private Sub ChangeColorsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            lstSample.ForeColor = CType(My.Settings.Item("lstforecolor"), System.Drawing.Color)
            lstSample.BackColor = CType(My.Settings.Item("lstbackcolor"), System.Drawing.Color)
        Catch
        End Try
    End Sub

    Private Sub lnkChangeForeColor_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkChangeForeColor.LinkClicked

        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            lstSample.ForeColor = cdColor.Color
        End If

    End Sub

    Private Sub lnkChangeBackColor_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkChangeBackColor.LinkClicked

        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            lstSample.BackColor = cdColor.Color
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub lnkReset_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkReset.LinkClicked

        My.Settings.Reset()
        Try
            lstSample.ForeColor = CType(My.Settings.Item("lstforecolor"), System.Drawing.Color)
            lstSample.BackColor = CType(My.Settings.Item("lstbackcolor"), System.Drawing.Color)
        Catch
        End Try
        btnCancel.Enabled = False
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        ' Save all changes made so far.
        My.Settings.Item("lstforecolor") = lstSample.ForeColor
        My.Settings.Item("lstbackcolor") = lstSample.BackColor
        Me.Close()
    End Sub
End Class
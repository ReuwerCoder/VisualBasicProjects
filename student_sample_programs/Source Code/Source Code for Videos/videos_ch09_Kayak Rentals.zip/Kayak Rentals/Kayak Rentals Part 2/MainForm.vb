﻿Imports System.IO

Public Class MainForm

    ' ADDED
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ReadRentalHistory()
    End Sub

    Private Sub ShowCustomerRentals()
        Dim frm As New RentalForm
        frm.ShowDialog()
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuCustomerRentals_Click(sender As Object, e As EventArgs) Handles mnuCustomerRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuManager_Click(sender As Object, e As EventArgs) Handles mnuManager.Click
        Dim frm As New ManagerMainForm
        frm.ShowDialog()
    End Sub

    Private Sub btnKayakRentals_Click(sender As Object, e As EventArgs) Handles btnKayakRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuCustomerTours_Click(sender As Object, e As EventArgs) Handles mnuCustomerTours.Click
        Dim frm As New SelectTourForm
        frm.ShowDialog()
    End Sub

    'ADDED
    Private Sub ReadRentalHistory()
        ' Read the Rental history from a file
        Dim historyFile As StreamReader
        Try
            If File.Exists(g_RentalHistoryFilename) Then
                historyFile = File.OpenText(g_RentalHistoryFilename)
                While Not historyFile.EndOfStream
                    Dim strLine As String = historyFile.ReadLine()
                    Dim fields() As String = strLine.Split(","c)
                    Dim R As New Rental
                    R.KayakType = fields(0)
                    R.Duration = fields(1)
                    R.Accessories = fields(2)
                    R.BasicRental = fields(3)
                    R.AccessoryCost = fields(4)
                    R.SalesTax = fields(5)
                    R.FinalTotal = fields(6)
                    g_RentalHistory.Add(R)
                End While
                historyFile.Close()
            End If
        Catch ex As FileNotFoundException
            MessageBox.Show("Cannot open rental history file")
        Catch ex As Exception
            MessageBox.Show("Invalid field found in input file")
        End Try
    End Sub

End Class
﻿Public Class RentalHistoryForm

    Private Sub RentalHistoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each R As Rental In g_RentalHistory
            lstHistory.Items.Add(R.KayakType & " rental for " & R.Duration)
            lstHistory.Items.Add(vbTab & "Accessories (" & R.AccessoryCost & "): " & R.Accessories)
            lstHistory.Items.Add(vbTab & "Total cost: " & R.FinalTotal)
            lstHistory.Items.Add(vbCrLf)
        Next
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
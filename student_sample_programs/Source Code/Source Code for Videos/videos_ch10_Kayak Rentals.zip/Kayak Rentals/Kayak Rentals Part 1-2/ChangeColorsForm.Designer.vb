﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChangeColorsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lnkReset = New System.Windows.Forms.LinkLabel()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lstSample = New System.Windows.Forms.ListBox()
        Me.lnkChangeBackColor = New System.Windows.Forms.LinkLabel()
        Me.lnkChangeForeColor = New System.Windows.Forms.LinkLabel()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.cdColor = New System.Windows.Forms.ColorDialog()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(1, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(453, 44)
        Me.Panel1.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(137, 7)
        Me.Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(170, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Change Colors"
        '
        'lnkReset
        '
        Me.lnkReset.AutoSize = True
        Me.lnkReset.Location = New System.Drawing.Point(42, 117)
        Me.lnkReset.Name = "lnkReset"
        Me.lnkReset.Size = New System.Drawing.Size(153, 17)
        Me.lnkReset.TabIndex = 35
        Me.lnkReset.TabStop = True
        Me.lnkReset.Text = "Reset to default values"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(253, 180)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(88, 28)
        Me.btnCancel.TabIndex = 34
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'lstSample
        '
        Me.lstSample.FormattingEnabled = True
        Me.lstSample.ItemHeight = 16
        Me.lstSample.Items.AddRange(New Object() {"Sample text", "Sample text", "Sample text"})
        Me.lstSample.Location = New System.Drawing.Point(273, 69)
        Me.lstSample.Name = "lstSample"
        Me.lstSample.Size = New System.Drawing.Size(122, 68)
        Me.lstSample.TabIndex = 33
        '
        'lnkChangeBackColor
        '
        Me.lnkChangeBackColor.AutoSize = True
        Me.lnkChangeBackColor.Location = New System.Drawing.Point(42, 90)
        Me.lnkChangeBackColor.Name = "lnkChangeBackColor"
        Me.lnkChangeBackColor.Size = New System.Drawing.Size(192, 17)
        Me.lnkChangeBackColor.TabIndex = 32
        Me.lnkChangeBackColor.TabStop = True
        Me.lnkChangeBackColor.Text = "Set background ListBox color"
        '
        'lnkChangeForeColor
        '
        Me.lnkChangeForeColor.AutoSize = True
        Me.lnkChangeForeColor.Location = New System.Drawing.Point(42, 64)
        Me.lnkChangeForeColor.Name = "lnkChangeForeColor"
        Me.lnkChangeForeColor.Size = New System.Drawing.Size(192, 17)
        Me.lnkChangeForeColor.TabIndex = 31
        Me.lnkChangeForeColor.TabStop = True
        Me.lnkChangeForeColor.Text = "Change foreground text color"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(83, 180)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(134, 28)
        Me.btnSave.TabIndex = 30
        Me.btnSave.Text = "Save Changes"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'ChangeColorsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 235)
        Me.ControlBox = False
        Me.Controls.Add(Me.lnkReset)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lstSample)
        Me.Controls.Add(Me.lnkChangeBackColor)
        Me.Controls.Add(Me.lnkChangeForeColor)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "ChangeColorsForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tony's Best Kayak Outfitters"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lnkReset As System.Windows.Forms.LinkLabel
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents lstSample As System.Windows.Forms.ListBox
    Friend WithEvents lnkChangeBackColor As System.Windows.Forms.LinkLabel
    Friend WithEvents lnkChangeForeColor As System.Windows.Forms.LinkLabel
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents cdColor As System.Windows.Forms.ColorDialog
End Class

﻿Imports System.IO

Public Class RentalForm

    Const dblTaxRate As Double = 0.07        ' sales tax rate
    Const dblBasicRentalRate As Double = 50.0     ' daily rate
    Const dblTandemSurcharge As Double = 20.0
    Const dblAccessoryPrice As Double = 5.0
    Private dblAccessories As Double = 0.0
    Private dblBasicRental As Double
    Private dblSubtotal As Double
    Private dblSalesTax As Double
    Private dblFinalTotal As Double
    Private rental As Rental

    Private Sub RentalForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each kType As String In KayakTypes
            cboKayakType.Items.Add(kType)
        Next
    End Sub

    Private Function ValidateKayakType() As Boolean

        ' Return True if a kayak type has been selected.
        lblMessage.Text = String.Empty
        If cboKayakType.SelectedItem Is Nothing Then
            lblMessage.Text = "Please select a kayak type"
            Return False
        Else
            Return True
        End If
    End Function

    Private Function ValidateRentalDuration() As Boolean

        ' Make sure the rental duration has been selected.
        lblMessage.Text = String.Empty
        If Not (radFullDay.Checked Or radHalfDay.Checked) Then
            lblMessage.Text = "Please select a rental duration"
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub CalcBasicRental()

        If radHalfDay.Checked Then
            dblBasicRental = HalfDayKayakRates(cboKayakType.SelectedIndex)
        ElseIf radFullDay.Checked Then
            dblBasicRental = FullDayKayakRates(cboKayakType.SelectedIndex)
        End If

    End Sub

    Private Sub CalcAccessoryCosts()

        ' Count the number of accessories. 
        Dim intCount As Integer = 0
        For i As Integer = 0 To lstAccessories.Items.Count - 1
            If lstAccessories.GetItemChecked(i) Then
                intCount += 1
            End If
        Next

        ' Multiply the number of accessories by a standard price.
        dblAccessories = intCount * dblAccessoryPrice
    End Sub

    Private Sub CalcSummaryTotals()

        ' Calculate the subtotal, sales tax, and final total.
        dblSubtotal = dblBasicRental + dblAccessories
        dblSalesTax = dblSubtotal * dblTaxRate
        dblFinalTotal = dblSubtotal + dblSalesTax
    End Sub

    Private Function Calculate() As Boolean
        ' This procedure validates the user's inputs, performs all calculations, 
        ' and displays the results.

        If ValidateKayakType() AndAlso ValidateRentalDuration() Then
            ' Do all of the calculations.
            CalcBasicRental()
            CalcAccessoryCosts()
            CalcSummaryTotals()

            ' Display the results
            lblBasicRental.Text = dblBasicRental.ToString("n")
            lblAccessories.Text = dblAccessories.ToString("n")
            lblSubtotal.Text = dblSubtotal.ToString("n")
            lblSalesTax.Text = dblSalesTax.ToString("n")
            lblFinalTotal.Text = dblFinalTotal.ToString("n")
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub btnCalculate_Click() Handles btnCalculate.Click

        Calculate()
    End Sub

    Private Sub btnClear_Click() Handles btnClear.Click

        rental = Nothing

        cboKayakType.SelectedIndex = -1
        lstAccessories.SelectedItems.Clear()
        radHalfDay.Checked = False
        radFullDay.Checked = False

        ' Uncheck all accessories.
        For i As Integer = 0 To lstAccessories.Items.Count - 1
            lstAccessories.SetItemChecked(i, False)
        Next

        lblBasicRental.Text = String.Empty
        lblAccessories.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblSalesTax.Text = String.Empty
        lblFinalTotal.Text = String.Empty
        lblMessage.Text = String.Empty
    End Sub

    Private Sub btnClose_Click() Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub SaveAllRentals()

        ' Write the rental history list to the rental history file. Any existing
        ' file will be erased.
        Dim historyFile As StreamWriter
        historyFile = File.CreateText(g_RentalHistoryFilename)

        For Each aRental As Rental In g_RentalHistory
            historyFile.WriteLine(aRental.AsCommaDelimited())
        Next
        historyFile.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        If Calculate() Then
            rental = New Rental
            rental.KayakType = cboKayakType.Text
            If radFullDay.Checked Then
                rental.Duration = radFullDay.Text
            Else
                rental.Duration = radHalfDay.Text
            End If

            For Each obj As Object In lstAccessories.CheckedItems
                rental.Accessories &= obj.ToString() & " "
            Next

            rental.BasicRental = lblBasicRental.Text
            rental.AccessoryCost = lblAccessories.Text
            rental.SalesTax = lblSalesTax.Text
            rental.FinalTotal = lblFinalTotal.Text
            g_RentalHistory.Add(rental)

            SaveAllRentals()                    ' NEW

            lblMessage.Text = "This rental was saved in the history list"
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        If rental Is Nothing Then
            lblMessage.Text = "The rental must be saved before printing"
        Else
            lblMessage.Text = String.Empty
            pdPrint.Print()
        End If
    End Sub

    Private Sub pdPrint_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) _
        Handles pdPrint.PrintPage
        ' Handle the PrintPage event by printing the current invoice.

        ' Define some useful fonts
        Dim titleFont As New Font("Times New Roman", 24, FontStyle.Bold)
        Dim boldFont = New Font("Times New Roman", 12, FontStyle.Bold)
        Dim detailFont = New Font("Times New Roman", 11, FontStyle.Regular)

        Dim intX As Integer = 20
        Dim intY As Integer = 20

        ' Print the company name, and date, and report title.
        e.Graphics.DrawString("Tony's Best Kayak Outfitters", boldFont, Brushes.Black, intX, intY)
        intY += 30
        e.Graphics.DrawString("Date: " & Today.ToString("d"), detailFont, Brushes.Black, intX, intY)
        intY += 80
        e.Graphics.DrawString("Rental Invoice", titleFont, Brushes.Black, intX, intY)
        intY += 50

        ' Print the fields in the Rental object.
        e.Graphics.DrawString(rental.ToString(), detailFont, Brushes.Black, intX, intY)
    End Sub
End Class
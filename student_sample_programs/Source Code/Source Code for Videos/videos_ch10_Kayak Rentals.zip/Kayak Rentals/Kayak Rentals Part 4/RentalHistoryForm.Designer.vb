﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RentalHistoryForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.dgvHistory = New System.Windows.Forms.DataGridView()
        Me.KayakRentalsDataSet = New Kayak_Rentals.KayakRentalsDataSet()
        Me.RentalHistoryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RentalHistoryTableAdapter = New Kayak_Rentals.KayakRentalsDataSetTableAdapters.RentalHistoryTableAdapter()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DurationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccessoriesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BasicRentalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccessoryCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalesTaxDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FinalTotalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KayakRentalsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RentalHistoryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(13, 13)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(661, 55)
        Me.Panel1.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(260, 16)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(176, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Rental History"
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnClose.Location = New System.Drawing.Point(311, 362)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(87, 27)
        Me.btnClose.TabIndex = 18
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'dgvHistory
        '
        Me.dgvHistory.AllowUserToAddRows = False
        Me.dgvHistory.AllowUserToDeleteRows = False
        Me.dgvHistory.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvHistory.AutoGenerateColumns = False
        Me.dgvHistory.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHistory.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DescriptionDataGridViewTextBoxColumn, Me.DurationDataGridViewTextBoxColumn, Me.AccessoriesDataGridViewTextBoxColumn, Me.BasicRentalDataGridViewTextBoxColumn, Me.AccessoryCostDataGridViewTextBoxColumn, Me.SalesTaxDataGridViewTextBoxColumn, Me.FinalTotalDataGridViewTextBoxColumn})
        Me.dgvHistory.DataSource = Me.RentalHistoryBindingSource
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvHistory.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvHistory.Location = New System.Drawing.Point(13, 75)
        Me.dgvHistory.Name = "dgvHistory"
        Me.dgvHistory.ReadOnly = True
        Me.dgvHistory.RowHeadersVisible = False
        Me.dgvHistory.Size = New System.Drawing.Size(662, 281)
        Me.dgvHistory.TabIndex = 19
        '
        'KayakRentalsDataSet
        '
        Me.KayakRentalsDataSet.DataSetName = "KayakRentalsDataSet"
        Me.KayakRentalsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RentalHistoryBindingSource
        '
        Me.RentalHistoryBindingSource.DataMember = "RentalHistory"
        Me.RentalHistoryBindingSource.DataSource = Me.KayakRentalsDataSet
        '
        'RentalHistoryTableAdapter
        '
        Me.RentalHistoryTableAdapter.ClearBeforeFill = True
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "Description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        Me.DescriptionDataGridViewTextBoxColumn.ReadOnly = True
        Me.DescriptionDataGridViewTextBoxColumn.Width = 200
        '
        'DurationDataGridViewTextBoxColumn
        '
        Me.DurationDataGridViewTextBoxColumn.DataPropertyName = "Duration"
        Me.DurationDataGridViewTextBoxColumn.HeaderText = "Duration"
        Me.DurationDataGridViewTextBoxColumn.Name = "DurationDataGridViewTextBoxColumn"
        Me.DurationDataGridViewTextBoxColumn.ReadOnly = True
        Me.DurationDataGridViewTextBoxColumn.Width = 60
        '
        'AccessoriesDataGridViewTextBoxColumn
        '
        Me.AccessoriesDataGridViewTextBoxColumn.DataPropertyName = "Accessories"
        Me.AccessoriesDataGridViewTextBoxColumn.HeaderText = "Accessories"
        Me.AccessoriesDataGridViewTextBoxColumn.Name = "AccessoriesDataGridViewTextBoxColumn"
        Me.AccessoriesDataGridViewTextBoxColumn.ReadOnly = True
        Me.AccessoriesDataGridViewTextBoxColumn.Width = 300
        '
        'BasicRentalDataGridViewTextBoxColumn
        '
        Me.BasicRentalDataGridViewTextBoxColumn.DataPropertyName = "BasicRental"
        Me.BasicRentalDataGridViewTextBoxColumn.HeaderText = "Basic Rental"
        Me.BasicRentalDataGridViewTextBoxColumn.Name = "BasicRentalDataGridViewTextBoxColumn"
        Me.BasicRentalDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AccessoryCostDataGridViewTextBoxColumn
        '
        Me.AccessoryCostDataGridViewTextBoxColumn.DataPropertyName = "AccessoryCost"
        Me.AccessoryCostDataGridViewTextBoxColumn.HeaderText = "Accessory Cost"
        Me.AccessoryCostDataGridViewTextBoxColumn.Name = "AccessoryCostDataGridViewTextBoxColumn"
        Me.AccessoryCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SalesTaxDataGridViewTextBoxColumn
        '
        Me.SalesTaxDataGridViewTextBoxColumn.DataPropertyName = "SalesTax"
        Me.SalesTaxDataGridViewTextBoxColumn.HeaderText = "Sales Tax"
        Me.SalesTaxDataGridViewTextBoxColumn.Name = "SalesTaxDataGridViewTextBoxColumn"
        Me.SalesTaxDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FinalTotalDataGridViewTextBoxColumn
        '
        Me.FinalTotalDataGridViewTextBoxColumn.DataPropertyName = "FinalTotal"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle1.Format = "N2"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.FinalTotalDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle1
        Me.FinalTotalDataGridViewTextBoxColumn.HeaderText = "Final Total"
        Me.FinalTotalDataGridViewTextBoxColumn.Name = "FinalTotalDataGridViewTextBoxColumn"
        Me.FinalTotalDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RentalHistoryForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(687, 401)
        Me.Controls.Add(Me.dgvHistory)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "RentalHistoryForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tony's Best Kayak Outfitters"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgvHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KayakRentalsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RentalHistoryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents dgvHistory As System.Windows.Forms.DataGridView
    Friend WithEvents KayakRentalsDataSet As Kayak_Rentals.KayakRentalsDataSet
    Friend WithEvents RentalHistoryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents RentalHistoryTableAdapter As Kayak_Rentals.KayakRentalsDataSetTableAdapters.RentalHistoryTableAdapter
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DurationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccessoriesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BasicRentalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccessoryCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SalesTaxDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FinalTotalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class

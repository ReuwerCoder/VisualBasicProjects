﻿Public Class RentalHistoryForm

    Private Sub RentalHistoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'KayakRentalsDataSet.RentalHistory' table. You can move, or remove it, as needed.
        Me.RentalHistoryTableAdapter.Fill(Me.KayakRentalsDataSet.RentalHistory)



    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

End Class
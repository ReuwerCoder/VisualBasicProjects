﻿Public Class RentalHistoryForm

    Private Sub RentalHistoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'KayakRentalsDataSet.RentalDates' table. You can move, or remove it, as needed.
        Me.RentalDatesTableAdapter.Fill(Me.KayakRentalsDataSet.RentalDates)
        Me.RentalHistoryTableAdapter.Fill(Me.KayakRentalsDataSet.RentalHistory)

        cboDates.SelectedIndex = -1
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged

        If txtFirstName.Text.Length = 0 Then
            Me.RentalHistoryTableAdapter.Fill(Me.KayakRentalsDataSet.RentalHistory)
        Else
            Me.RentalHistoryTableAdapter.FillByFirstName(Me.KayakRentalsDataSet.RentalHistory,
                    txtFirstName.Text)
        End If
    End Sub

    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged

        If txtLastName.Text.Length = 0 Then
            Me.RentalHistoryTableAdapter.Fill(Me.KayakRentalsDataSet.RentalHistory)
        Else
            Me.RentalHistoryTableAdapter.FillByLastName(Me.KayakRentalsDataSet.RentalHistory,
                    txtLastName.Text)
        End If

    End Sub

    Private Sub cboDates_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDates.SelectedIndexChanged

        If cboDates.SelectedIndex = -1 Then Return

        Me.RentalHistoryTableAdapter.FillByRentalDate(Me.KayakRentalsDataSet.RentalHistory,
                   CDate(cboDates.SelectedValue))
    End Sub

    Private Sub cboDates_TextChanged(sender As Object, e As EventArgs) Handles cboDates.TextChanged
        If cboDates.Text.Length = 0 Then
            Me.RentalHistoryTableAdapter.Fill(Me.KayakRentalsDataSet.RentalHistory)
        End If
    End Sub
End Class
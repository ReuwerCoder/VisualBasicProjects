﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        Response.Redirect("AddFilm.aspx")
    End Sub
End Class

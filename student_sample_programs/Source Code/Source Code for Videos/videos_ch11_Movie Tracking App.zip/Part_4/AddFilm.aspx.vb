﻿
Partial Class AddFilm
    Inherits System.Web.UI.Page

    Protected Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class

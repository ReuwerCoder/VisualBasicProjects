﻿Module Globals

    Public ReadOnly g_RentalHistoryFilename As String = "rental_history.txt"

    Public g_RentalHistory As New RentalHistory
    Public g_TourHistory As New List(Of TourHistoryItem)
    Public g_AllKayaks As New List(Of Kayak)

    Public g_Tours As New List(Of KayakTour)

End Module

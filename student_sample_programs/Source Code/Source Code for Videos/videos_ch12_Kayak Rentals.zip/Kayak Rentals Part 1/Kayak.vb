﻿Public Class Kayak
    Public Property Type As KayakType
    Public Property HalfDayRate As Double
    Public Property FullDayRate As Double

    Public Sub New(pType As KayakType, pHalfRate As Double,
                   pFullRate As Double)
        Type = pType
        HalfDayRate = pHalfRate
        FullDayRate = pFullRate
    End Sub
End Class

Public Enum KayakType
    SoloRecreational
    SoloTouring
    SoloOcean
    TandemRecreational
    TandemTouring
    TandemOcean
End Enum
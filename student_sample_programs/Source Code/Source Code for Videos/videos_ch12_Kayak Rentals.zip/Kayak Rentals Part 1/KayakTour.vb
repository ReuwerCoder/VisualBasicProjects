﻿Public Class KayakTour

    Public Property Name As String
    Public Property Price As Double

    Public Sub New(pName As String, pPrice As Double)
        Name = pName
        Price = pPrice
    End Sub
End Class

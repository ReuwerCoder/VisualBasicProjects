﻿Imports System.IO

Public Class MainForm

    Private ReadOnly halfRate As Double() = {40.0, 48.0, 42.0, 48.0, 52.0, 55.0}
    Private ReadOnly fullRate As Double() = {70.0, 74.0, 78.0, 75.0, 80.0, 85.0}
    Private ReadOnly kayakTypes As KayakType() = {KayakType.SoloOcean, KayakType.SoloRecreational,
            KayakType.SoloTouring, KayakType.TandemOcean, KayakType.TandemRecreational,
            KayakType.TandemTouring}

    Private ReadOnly dblTourPrices() As Double = {55.0, 85.0, 105.0, 130.0}
    Private ReadOnly strTourNames() As String = {"Half-day harbor tour",
        "Full-day Rattlesnake Key",
        "Overnight Florida Bay",
        "Two-night Blackwater Sound"}

    Private Sub BuildKayakList()
        Const NUMKAYAKS As Integer = 6

        For i = 0 To NUMKAYAKS - 1
            Dim k As New Kayak(kayakTypes(i), halfRate(i), fullRate(i))
            g_AllKayaks.Add(k)
        Next
    End Sub

    Private Sub BuildTourList()
        'Build a list of kayak tours

        Const NUMTOURS As Integer = 4
        For i = 0 To NUMTOURS - 1
            g_Tours.Add(New KayakTour(strTourNames(i), dblTourPrices(i)))
        Next
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BuildKayakList()
        BuildTourList()
        ReadRentalHistory()
    End Sub

    Private Sub ReadRentalHistory()

        Dim historyFile As StreamReader
        Try
            If File.Exists(g_RentalHistoryFilename) Then

                historyFile = File.OpenText(g_RentalHistoryFilename)
                While Not historyFile.EndOfStream
                    Dim strLine As String = historyFile.ReadLine()
                    Dim fields() As String = strLine.Split(","c)
                    Dim R As New RentalHistoryItem
                    R.KayakType = fields(0)
                    R.Duration = fields(1)
                    R.Accessories = fields(2)
                    R.BasicRental = fields(3)
                    R.AccessoryCost = fields(4)
                    R.SalesTax = fields(5)
                    R.FinalTotal = fields(6)
                    g_RentalHistory.Items.Add(R)
                End While
                historyFile.Close()
            End If
        Catch ex As FileNotFoundException
            MessageBox.Show("Cannot open rental history file")
        Catch ex As Exception
            MessageBox.Show("Invalid field found in input file")
        End Try
    End Sub

    Private Sub ShowCustomerRentals()
        Dim frm As New RentalForm
        frm.ShowDialog()
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuCustomerRentals_Click(sender As Object, e As EventArgs) Handles mnuCustomerRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuManager_Click(sender As Object, e As EventArgs) Handles mnuManager.Click
        Dim frm As New ManagerMainForm
        frm.ShowDialog()
    End Sub

    Private Sub btnKayakRentals_Click(sender As Object, e As EventArgs) Handles btnKayakRentals.Click
        ShowCustomerRentals()
    End Sub

    Private Sub mnuCustomerTours_Click(sender As Object, e As EventArgs) Handles mnuCustomerTours.Click
        Dim frm As New SelectTourForm
        frm.ShowDialog()
    End Sub

End Class
﻿Imports System.IO

Public Class RentalForm

    Const dblTaxRate As Double = 0.07        ' sales tax rate
    Const dblBasicRentalRate As Double = 50.0     ' daily rate
    Const dblTandemSurcharge As Double = 20.0
    Const dblAccessoryPrice As Double = 5.0

    Private dblAccessories As Double = 0.0
    Private dblBasicRental As Double
    Private dblSubtotal As Double
    Private dblSalesTax As Double
    Private dblFinalTotal As Double

    Private Sub RentalForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each kayak As Kayak In g_AllKayaks
            cboKayakType.Items.Add(kayak.Type.ToString())
        Next
    End Sub

    Private Function ValidateKayakType() As Boolean

        ' Return True if a kayak type has been selected.
        lblMessage.Text = String.Empty
        If cboKayakType.SelectedItem Is Nothing Then
            lblMessage.Text = "Please select a kayak type"
            Return False
        Else
            Return True
        End If
    End Function

    Private Function ValidateRentalDuration() As Boolean

        ' Make sure the rental duration has been selected.
        lblMessage.Text = String.Empty
        If Not (radFullDay.Checked Or radHalfDay.Checked) Then
            lblMessage.Text = "Please select a rental duration"
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub CalcBasicRental()

        If radHalfDay.Checked Then
            dblBasicRental = g_AllKayaks(cboKayakType.SelectedIndex).HalfDayRate
        ElseIf radFullDay.Checked Then
            dblBasicRental = g_AllKayaks(cboKayakType.SelectedIndex).FullDayRate
        End If
    End Sub

    Private Sub CalcAccessoryCosts()

        ' Count the number of accessories. 
        Dim intCount As Integer = 0
        For i As Integer = 0 To lstAccessories.Items.Count - 1
            If lstAccessories.GetItemChecked(i) Then
                intCount += 1
            End If
        Next

        ' Multiply the number of accessories by a standard price.
        dblAccessories = intCount * dblAccessoryPrice
    End Sub

    Private Sub CalcSummaryTotals()
        ' Calculate the subtotal, sales tax, and final total.

        dblSubtotal = dblBasicRental + dblAccessories
        dblSalesTax = dblSubtotal * dblTaxRate
        dblFinalTotal = dblSubtotal + dblSalesTax
    End Sub

    Private Sub Calculate()
        ' This procedure validates
        ' the user's inputs, performs all calculations, and displays the results.

        ' Validate the user inputs.
        If ValidateKayakType() AndAlso ValidateRentalDuration() Then

            ' Do all of the calculations.
            CalcBasicRental()
            CalcAccessoryCosts()
            CalcSummaryTotals()

            ' Display the results
            lblBasicRental.Text = dblBasicRental.ToString("n")
            lblAccessories.Text = dblAccessories.ToString("n")
            lblSubtotal.Text = dblSubtotal.ToString("n")
            lblSalesTax.Text = dblSalesTax.ToString("n")
            lblFinalTotal.Text = dblFinalTotal.ToString("n")
        End If
    End Sub

    Private Sub btnCalculate_Click() Handles btnCalculate.Click
        ' The user has clicked the Calculate button. 
        Calculate()
    End Sub

    Private Sub btnClear_Click() Handles btnClear.Click

        cboKayakType.SelectedIndex = -1
        lstAccessories.SelectedItems.Clear()
        radHalfDay.Checked = False
        radFullDay.Checked = False

        ' Uncheck all accessories.
        For i As Integer = 0 To lstAccessories.Items.Count - 1
            lstAccessories.SetItemChecked(i, False)
        Next

        lblBasicRental.Text = String.Empty
        lblAccessories.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblSalesTax.Text = String.Empty
        lblFinalTotal.Text = String.Empty
        lblMessage.Text = String.Empty
    End Sub

    Private Sub btnClose_Click() Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub SaveAllRentals()

        Dim historyFile As StreamWriter
        historyFile = File.CreateText(g_RentalHistoryFilename)
        For Each aRental As RentalHistoryItem In g_RentalHistory.Items
            historyFile.WriteLine(aRental.AsCommaDelimited())
        Next
        historyFile.Close()

    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Calculate()

        Dim rental As New RentalHistoryItem
        rental.KayakType = cboKayakType.Text
        If radFullDay.Checked Then
            rental.Duration = radFullDay.Text
        Else
            rental.Duration = radHalfDay.Text
        End If

        For Each obj As Object In lstAccessories.CheckedItems
            rental.Accessories &= obj.ToString() & " "
        Next
        rental.BasicRental = lblBasicRental.Text
        rental.AccessoryCost = lblAccessories.Text
        rental.SalesTax = lblSalesTax.Text
        rental.FinalTotal = lblFinalTotal.Text

        g_RentalHistory.Items.Add(rental)       ' add it to the history list
        SaveAllRentals()

        lblMessage.Text = "This rental was saved in the history list"
    End Sub

End Class
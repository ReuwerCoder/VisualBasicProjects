﻿Public Class RentalHistory

    Public Property Items As List(Of RentalHistoryItem)

    Public Sub New()
        Items = New List(Of RentalHistoryItem)

    End Sub

End Class

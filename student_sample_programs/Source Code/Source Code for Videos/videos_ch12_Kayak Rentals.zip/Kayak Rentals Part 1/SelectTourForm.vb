﻿Public Class SelectTourForm

    Private Sub SelectTourForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each tour As KayakTour In g_Tours
            lstTours.Items.Add(tour.Name)
        Next
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Dim index As Integer = lstTours.SelectedIndex
        If index = -1 Then
            lblStatus.Text = "Please select a tour from the list"
            Return
        Else
            lblPrice.Text = g_Tours(index).Price.ToString("c")
            lblStatus.Text = "Thank you for selecting a tour."

            Dim aTour As New TourHistoryItem()
            aTour.TourName = lstTours.SelectedItem.ToString()
            aTour.Price = CDbl(lblPrice.Text)
            aTour.CustomerFirstName = txtFirstName.Text
            aTour.CustomerLastName = txtLastName.Text
            g_TourHistory.Add(aTour)
        End If
    End Sub

    Private Sub lstTours_SelectedIndexChanged() Handles lstTours.SelectedIndexChanged

        Dim index As Integer = lstTours.SelectedIndex
        lblPrice.Text = g_Tours(index).Price.ToString("c")
        lblStatus.Text = String.Empty
    End Sub
End Class